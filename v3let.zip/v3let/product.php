<!DOCTYPE html>
<html lang="ru">

<head>
  <title>Подробнее</title>
  <meta name="robots" content="index, follow">
  <meta name="keywords"
    content="ХВВАУЛ,Харьковское ВВАУЛ,Харьковское высшее военное авиационное училище лётчиков,выпускники 1974 года,выпуск 1974 года, лучший сайт авиации">
  <meta name="description"
    content="Сайт выпускников ХВВАУЛ 1974 года выпуска, ХВВАУЛ-74, Взлёт.ру, v3let.ru, лучший сайт авиации">
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link type="image/x-icon" rel="shortcut icon" href="images/favicon.ico">
  <link rel="stylesheet" href="css/style.min.css">
</head>

<body>
  <div class="wrapper">
    <header class="header">
      <div class="header-top">
        <div class="container">
          <div class="header-top__inner"><img src="images/star.png" alt="Орден" class="star"
              style="width: 50px; height: 50px">
            <p class="header-top__content">[ХВВАУЛ-74] Харьковское Высшее Военное Авиационное ордена Красной Звезды
              Училище Лётчиков ВВС им. дважды Героя Советского Союза С.И. Грицевца</p>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="header__inner">
          <div class="header__about" data-aos="fade-left" data-aos-duration="1000">
            <h1 class="header__title"><a href="/" class="header__link">Взлёт</a></h1><span class="header__subtitle">Сайт
              выпускников 1974 года</span>
          </div>
          <nav class="menu">
            <ul class="menu__list">
              <li class="menu__item"><svg class="menu__pic">
                  <use xlink:href="images/sprite.svg#users"></use>
                </svg> <a href="./index.html#slide" class="menu__link">Наш курс</a></li>
              <li class="menu__item"><svg class="menu__pic">
                  <use xlink:href="images/sprite.svg#history"></use>
                </svg> <a href="./history.html" class="menu__link">Исторические хроники</a></li>
              <li class="menu__item"><svg class="menu__pic">
                  <use xlink:href="images/sprite.svg#art"></use>
                </svg> <a href="./art.html" class="menu__link">Творчество</a></li>
              <li class="menu__item"><svg class="menu__pic">
                  <use xlink:href="images/sprite.svg#author"></use>
                </svg> <a href="./author.html" class="menu__link">Юрий Фёдоров</a></li>
              <li class="menu__item"><svg class="menu__pic">
                  <use xlink:href="images/sprite.svg#help"></use>
                </svg> <a href="#" class="menu__link" data-modal="data-modal">Помощь</a></li>
            </ul><button class="menu__btn"><span>Меню</span> <svg class="menu__icon">
                <use xlink:href="images/sprite.svg#menu"></use>
              </svg></button>
          </nav>
        </div>
      </div>
    </header>
    <main class="main">
      <div class="container">
        <div class="bar">
          <dvi class="social">
            <ul class="social__list">
              <li class="social__item"><a href="https://ok.ru/profile/529378520930" target="_blank"
                  class="social__link"><svg class="social__icon">
                    <use xlink:href="images/sprite.svg#odnok"></use>
                  </svg></a></li>
              <li class="social__item"><a href="https://telegram.me/v3letRu" target="_blank" class="social__link"><svg
                    class="social__icon">
                    <use xlink:href="images/sprite.svg#telegram"></use>
                  </svg></a></li>
              <li class="social__item"><a href="mailto:admin@v3let.ru" class="social__link"><svg class="social__icon">
                    <use xlink:href="images/sprite.svg#email"></use>
                  </svg></a></li>
            </ul>
          </dvi>
          <div class="search">
            <form action="#" class="search__form"><input type="text" class="search__input" placeholder="Поиск"> <button
                class="search__btn"><svg class="search__icon">
                  <use xlink:href="images/sprite.svg#search"></use>
                </svg></button></form>
          </div>
        </div>
      </div>
      <section class="product">
        <div class="container">
          <article class="product__wrapper" data-aos="slide-up" data-aos-duration="1000">
            <div class="product__content">
              <h2 class="product__title">Добро пожаловать на сайт "Взлет.ру"!</h2>
              <p class="product__text" data-aos="fade-in" data-aos-duration="1000"><img src="/images/content/2.jpg"
                  alt="Изображение" class="product__img" data-aos="fade-in" data-aos-duration="1000"> Дорогие друзья!
                Теперь и у нашего выпуска Харьковского ВВАУЛ 1974 года есть свой сайт. Заходите, регистрируйтесь,
                смотрите материалы, присылайте свои мысли, воспоминания, стихи, рассказы, пожелания, замечания ,
                восхищения и, конечно же, фотографии – то есть всё то, чем вы хотите поделиться со своими однокашниками.
                Именно это сделает наш сайт красивым и, возможно, посещаемым другими пользователями. Цель сайта: собрать
                как можно больше информации о всех выпускниках ХВВАУЛ, сделать информацию полезной и интересной. Дорогие
                друзья! Теперь и у нашего выпуска Харьковского ВВАУЛ 1974 года есть свой сайт. Заходите,
                регистрируйтесь, смотрите материалы, присылайте свои мысли, воспоминания, стихи, рассказы, пожелания,
                замечания , восхищения и, конечно же, фотографии – то есть всё то, чем вы хотите поделиться со своими
                однокашниками. Именно это сделает наш сайт красивым и, возможно, посещаемым другими пользователями. Цель
                сайта: собрать как можно больше информации о всех выпускниках ХВВАУЛ, сделать информацию полезной и
                интересной. Дорогие друзья! Теперь и у нашего выпуска Харьковского ВВАУЛ 1974 года есть свой сайт.
                Заходите, регистрируйтесь, смотрите материалы, присылайте свои мысли, воспоминания, стихи, рассказы,
                пожелания, замечания , восхищения и, конечно же, фотографии – то есть всё то, чем вы хотите поделиться
                со своими однокашниками. Именно это сделает наш сайт красивым и, возможно, посещаемым другими
                пользователями. Цель сайта: собрать как можно больше информации о всех выпускниках ХВВАУЛ, сделать
                информацию полезной и интересной. Дорогие друзья! Теперь и у нашего выпуска Харьковского ВВАУЛ 1974 года
                есть свой сайт. Заходите, регистрируйтесь, смотрите материалы, присылайте свои мысли, воспоминания,
                стихи, рассказы, пожелания, замечания , восхищения и, конечно же, фотографии – то есть всё то, чем вы
                хотите поделиться со своими однокашниками. Именно это сделает наш сайт красивым и, возможно, посещаемым
                другими пользователями. Цель сайта: собрать как можно больше информации о всех выпускниках ХВВАУЛ,
                сделать информацию полезной и интересной. Дорогие друзья! Теперь и у нашего выпуска Харьковского ВВАУЛ
                1974 года есть свой сайт. Заходите, регистрируйтесь, смотрите материалы, присылайте свои мысли,
                воспоминания, стихи, рассказы, пожелания, замечания , восхищения и, конечно же, фотографии – то есть всё
                то, чем вы хотите поделиться со своими однокашниками. Именно это сделает наш сайт красивым и, возможно,
                посещаемым другими пользователями. Цель сайта: собрать как можно больше информации о всех выпускниках
                ХВВАУЛ, сделать информацию полезной и интересной. Дорогие друзья! Теперь и у нашего выпуска Харьковского
                ВВАУЛ 1974 года есть свой сайт. Заходите, регистрируйтесь, смотрите материалы, присылайте свои мысли,
                воспоминания, стихи, рассказы, пожелания, замечания , восхищения и, конечно же, фотографии – то есть всё
                то, чем вы хотите поделиться со своими однокашниками. Именно это сделает наш сайт красивым и, возможно,
                посещаемым другими пользователями. Цель сайта: собрать как можно больше информации о всех выпускниках
                ХВВАУЛ, сделать информацию полезной и интересной. Дорогие друзья! Теперь и у нашего выпуска Харьковского
                ВВАУЛ 1974 года есть свой сайт. Заходите, регистрируйтесь, смотрите материалы, присылайте свои мысли,
                воспоминания, стихи, рассказы, пожелания, замечания , восхищения и, конечно же, фотографии – то есть всё
                то, чем вы хотите поделиться со своими однокашниками. Именно это сделает наш сайт красивым и, возможно,
                посещаемым другими пользователями. Цель сайта: собрать как можно больше информации о всех выпускниках
                ХВВАУЛ, сделать информацию полезной и интересной. Дорогие друзья! Теперь и у нашего выпуска Харьковского
                ВВАУЛ 1974 года есть свой сайт. Заходите, регистрируйтесь, смотрите материалы, присылайте свои мысли,
                воспоминания, стихи, рассказы, пожелания, замечания , восхищения и, конечно же, фотографии – то есть всё
                то, чем вы хотите поделиться со своими однокашниками. Именно это сделает наш сайт красивым и, возможно,
                посещаемым другими пользователями. Цель сайта: собрать как можно больше информации о всех выпускниках
                ХВВАУЛ, сделать информацию полезной и интересной. Дорогие друзья! Теперь и у нашего выпуска Харьковского
                ВВАУЛ 1974 года есть свой сайт. Заходите, регистрируйтесь, смотрите материалы, присылайте свои мысли,
                воспоминания, стихи, рассказы, пожелания, замечания , восхищения и, конечно же, фотографии – то есть всё
                то, чем вы хотите поделиться со своими однокашниками. Именно это сделает наш сайт красивым и, возможно,
                посещаемым другими пользователями. Цель сайта: собрать как можно больше информации о всех выпускниках
                ХВВАУЛ, сделать информацию полезной и интересной. Дорогие друзья! Теперь и у нашего выпуска Харьковского
                ВВАУЛ 1974 года есть свой сайт. Заходите, регистрируйтесь, смотрите материалы, присылайте свои мысли,
                воспоминания, стихи, рассказы, пожелания, замечания , восхищения и, конечно же, фотографии – то есть всё
                то, чем вы хотите поделиться со своими однокашниками. Именно это сделает наш сайт красивым и, возможно,
                посещаемым другими пользователями. Цель сайта: собрать как можно больше информации о всех выпускниках
                ХВВАУЛ, сделать информацию полезной и интересной. Дорогие друзья! Теперь и у нашего выпуска Харьковского
                ВВАУЛ 1974 года есть свой сайт. Заходите, регистрируйтесь, смотрите материалы, присылайте свои мысли,
                воспоминания, стихи, рассказы, пожелания, замечания , восхищения и, конечно же, фотографии – то есть всё
                то, чем вы хотите поделиться со своими однокашниками. Именно это сделает наш сайт красивым и, возможно,
                посещаемым другими пользователями. Цель сайта: собрать как можно больше информации о всех выпускниках
                ХВВАУЛ, сделать информацию полезной и интересной. Дорогие друзья! Теперь и у нашего выпуска Харьковского
                ВВАУЛ 1974 года есть свой сайт. Заходите, регистрируйтесь, смотрите материалы, присылайте свои мысли,
                воспоминания, стихи, рассказы, пожелания, замечания , восхищения и, конечно же, фотографии – то есть всё
                то, чем вы хотите поделиться со своими однокашниками. Именно это сделает наш сайт красивым и, возможно,
                посещаемым другими пользователями. Цель сайта: собрать как можно больше информации о всех выпускниках
                ХВВАУЛ, сделать информацию полезной и интересной.</p>
            </div>
          </article>
        </div>
      </section>
      <section class="comments">коментарии</section><button class="up"><svg class="up__icon">
          <use xlink:href="images/sprite.svg#up"></use>
        </svg></button>
      <div class="modal hide">
        <div class="modal__dialog">
          <div class="modal__content"><span class="modal__title">Контактная информация!</span>
            <div class="modal__inner">
              <div class="modal__person">
                <div class="modal__close" data-close="">&times;</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <footer class="footer">
      <div class="container">
        <div class="footer__inner">
          <ol class="footer__txt">
            <li class="footer__copy">Взлет® - лучший сайт об авиации.</li>
            <li class="footer__copy">© Все права защищены 2007-2022г.</li>
          </ol>
          <dvi class="social">
            <ul class="social__list">
              <li class="social__item"><a href="https://ok.ru/profile/529378520930" target="_blank"
                  class="social__link"><svg class="social__icon">
                    <use xlink:href="images/sprite.svg#odnok"></use>
                  </svg></a></li>
              <li class="social__item"><a href="https://telegram.me/v3letRu" target="_blank" class="social__link"><svg
                    class="social__icon">
                    <use xlink:href="images/sprite.svg#telegram"></use>
                  </svg></a></li>
              <li class="social__item"><a href="mailto:admin@v3let.ru" class="social__link"><svg class="social__icon">
                    <use xlink:href="images/sprite.svg#email"></use>
                  </svg></a></li>
            </ul>
          </dvi>
        </div>
        <div class="created"><svg xmlns="http://www.w3.org/2000/svg" class="created__icon" width="32" height="32"
            viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="#fff" stroke-linecap="round"
            stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path
              d="M4 7h3a1 1 0 0 0 1 -1v-1a2 2 0 0 1 4 0v1a1 1 0 0 0 1 1h3a1 1 0 0 1 1 1v3a1 1 0 0 0 1 1h1a2 2 0 0 1 0 4h-1a1 1 0 0 0 -1 1v3a1 1 0 0 1 -1 1h-3a1 1 0 0 1 -1 -1v-1a2 2 0 0 0 -4 0v1a1 1 0 0 1 -1 1h-3a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1h1a2 2 0 0 0 0 -4h-1a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1" />
          </svg> Created by <a href="https://cloudy1gor.github.io" class="created__link" target="_blank">Савельев
            Игорь</a></div>
      </div>
    </footer>
  </div>
  <script src="js/product.min.js"></script>
</body>

</html>