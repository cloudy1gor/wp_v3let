<?php

function wfmtest_debug($data)
{
  echo '<pre>' . print_r($data, 1) . '</pre>';
}

function v3let_scripts()
{
  wp_enqueue_style('v3let-main', get_template_directory_uri() . '/assets/css/style.min.css');

  wp_enqueue_script('v3let-script', get_template_directory_uri() . '/assets/js/main.min.js', array(), false, true);
}

add_action('wp_enqueue_scripts', 'v3let_scripts');

//обрезает текст символом ...
add_filter('excerpt_more', function ($more) {
  return '...';
});

//время публикации записи
function v3let_get_human_time()
{
  $time_diff = human_time_diff(get_post_time('U'), current_time('timestamp'));
  return "Опубликовано $time_diff";
}

//настройка темы
function v3let_setup() {
  //изображения
	add_theme_support( 'post-thumbnails' );
}

add_action( 'after_setup_theme', 'v3let_setup' );

// настройка изображения
function v3let_post_thumb($id, $size = 'full', $wrapper_class = 'content__img lazy') {
//	global $post;
	$html = '<div class="' . $wrapper_class . '">';
	if ( has_post_thumbnail() ) {
		$html .= get_the_post_thumbnail( $id, $size );
	} else {
		$html .= '<img src="https://picsum.photos/1200/900?grayscale" alt="" width="400" height="250">';
	}
	$html .= '</div>';

	return $html;
}

?>