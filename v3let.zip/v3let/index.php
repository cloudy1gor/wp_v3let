<?php get_header() ?>

<main class="main" data-aos="slide-up">
  <div class="container">
    <div class="bar">
      <dvi class="social">
        <ul class="social__list">
          <li class="social__item"><a href="https://ok.ru/profile/529378520930" target="_blank"
              class="social__link"><svg class="social__icon">
                <use xlink:href="images/sprite.svg#odnok"></use>
              </svg></a></li>
          <li class="social__item"><a href="https://telegram.me/v3letRu" target="_blank" class="social__link"><svg
                class="social__icon">
                <use xlink:href="images/sprite.svg#telegram"></use>
              </svg></a></li>
          <li class="social__item"><a href="mailto:admin@v3let.ru" class="social__link"><svg class="social__icon">
                <use xlink:href="images/sprite.svg#email"></use>
              </svg></a></li>
        </ul>
      </dvi>
      <div class="search">
        <form action="#" class="search__form"><input type="text" class="search__input" placeholder="Поиск"> <button
            class="search__btn"><svg class="search__icon">
              <use xlink:href="images/sprite.svg#search"></use>
            </svg></button></form>
      </div>
    </div>
    <section class="content">
      <h2 class="title">Самое важное</h2>
      <div class="content__inner">

        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <!-- Цикл WordPress -->
        <article class="content__item">
          <a href="<?php the_permalink(); ?>" target="_blank" class="content__link"></a>
          <div class="content__img-container">
            <!-- <img data-src="<?php bloginfo( 'temlate_url' ); ?>/assets/images/content/1.jpg" src="<?php bloginfo( 'temlate_url' ); ?>/assets/images/1x1.png"
              alt="Изображение статьи" class="content__img lazy"> -->

            <?php echo v3let_post_thumb( get_the_ID() ) ?>
          </div>
          <h3 class="content__title"><?php the_title(); ?></h3>
          <p class="content__text"><?php the_excerpt(); //the_content('');
                                        ?></p>
          <time class="content__date">
            <?php //echo wfmtest_get_human_time();
                ?>
            <?php the_time('j F Y'); ?>
          </time>
        </article>
        <?php endwhile;
        else : ?>
        <p>Записей нет.</p>
        <?php endif; ?>

      </div><button class="news__btn btn"><span>Показать все новости</span></button>
    </section>

    <section class="slider" data-aos="fade-up">
      <div class="contaner">
        <h2 class="title">Наши выпускники</h2>
      </div>
      <div class="slider__container swiper">
        <ul class="slider__list swiper-wrapper">
          <li class="slider__item swiper-slide"><a href="./product.html" target="_blank"
              class="slider__link swiper-zoom-container"><img data-src="images/slider/1.jpg" src="images/1x1.png"
                alt="Фото" class="slider__img swiper-lazy">
              <div class="swiper-lazy-preloader"></div>
            </a></li>
          <li class="slider__item swiper-slide"><a href="./product.html" target="_blank"
              class="slider__link swiper-zoom-container"><img data-src="images/slider/2.jpg" src="images/1x1.png"
                alt="Фото" class="slider__img swiper-lazy">
              <div class="swiper-lazy-preloader"></div>
            </a></li>
          <li class="slider__item swiper-slide"><a href="./product.html" target="_blank"
              class="slider__link swiper-zoom-container"><img data-src="images/slider/3.jpg" src="images/1x1.png"
                alt="Фото" class="slider__img swiper-lazy">
              <div class="swiper-lazy-preloader"></div>
            </a></li>
          <li class="slider__item swiper-slide"><a href="./product.html" target="_blank"
              class="slider__link swiper-zoom-container"><img data-src="images/slider/4.jpg" src="images/1x1.png"
                alt="Фото" class="slider__img swiper-lazy">
              <div class="swiper-lazy-preloader"></div>
            </a></li>
          <li class="slider__item swiper-slide"><a href="./product.html" target="_blank"
              class="slider__link swiper-zoom-container"><img data-src="images/slider/5.jpg" src="images/1x1.png"
                alt="Фото" class="slider__img swiper-lazy">
              <div class="swiper-lazy-preloader"></div>
            </a></li>
          <li class="slider__item swiper-slide"><a href="./product.html" target="_blank"
              class="slider__link swiper-zoom-container"><img data-src="images/slider/6.jpg" src="images/1x1.png"
                alt="Фото" class="slider__img swiper-lazy">
              <div class="swiper-lazy-preloader"></div>
            </a></li>
        </ul>
      </div>
    </section>

    <section class="news" data-aos="fade-up">
      <div class="container">
        <h2 class="title" data-aos="fade-up">Свежие статьи</h2>
        <ul class="news__list">
          <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
          <!-- Цикл WordPress -->
          <li class="news__item">
            <article class="news__element" data-aos="slide-up"><a href="./product.html" target="_blank"
                class="news__link"></a> <img data-src="images/news/1.jpg" alt="Новостная карточка"
                class="news__image lazy">
              <div class="news__info">
                <h3 class="news__title"><?php the_title() ?></h3>
                <p class="news__text">
                  <?php the_excerpt(); ?>
                </p>
                <time class="news__date"><?php the_time('j F Y') ?></time>
              </div>
            </article>
          </li>
          <?php endwhile;
          else : ?>
          <p>Записей нет.</p>
          <?php endif; ?>
        </ul>
        <button class="news__btn btn">
          <span>Показать все новости</span>
        </button>
      </div>
    </section>
    <div class="up-wrapper"><button class="up up--animated"><span class="up__txt">Наверх</span> <svg class="up__icon">
          <use xlink:href="images/sprite.svg#up"></use>
        </svg></button></div>
  </div>
  <div class="modal hide">
    <div class="modal__dialog">
      <div class="modal__content"><span class="modal__title">Контактная информация!</span>
        <div class="modal__inner">
          <div class="modal__person">
            <div class="modal__close" data-close="">&times;</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<?php get_footer() ?>