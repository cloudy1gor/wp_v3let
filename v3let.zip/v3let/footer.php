    <footer class="footer">
      <div class="container">
        <div class="footer__inner">
          <ol class="footer__txt">
            <li class="footer__copy">Взлет® - лучший сайт об авиации.</li>
            <li class="footer__copy">© Все права защищены 2007-2022г.</li>
          </ol>
          <dvi class="social">
            <ul class="social__list">
              <li class="social__item"><a href="https://ok.ru/profile/529378520930" target="_blank" class="social__link"><svg class="social__icon">
                    <use xlink:href="images/sprite.svg#odnok"></use>
                  </svg></a></li>
              <li class="social__item"><a href="https://telegram.me/v3letRu" target="_blank" class="social__link"><svg class="social__icon">
                    <use xlink:href="images/sprite.svg#telegram"></use>
                  </svg></a></li>
              <li class="social__item"><a href="mailto:admin@v3let.ru" class="social__link"><svg class="social__icon">
                    <use xlink:href="images/sprite.svg#email"></use>
                  </svg></a></li>
            </ul>
          </dvi>
        </div>
        <div class="created"><svg xmlns="http://www.w3.org/2000/svg" class="created__icon" width="32" height="32" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" fill="#fff" stroke-linecap="round" stroke-linejoin="round">
            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
            <path d="M4 7h3a1 1 0 0 0 1 -1v-1a2 2 0 0 1 4 0v1a1 1 0 0 0 1 1h3a1 1 0 0 1 1 1v3a1 1 0 0 0 1 1h1a2 2 0 0 1 0 4h-1a1 1 0 0 0 -1 1v3a1 1 0 0 1 -1 1h-3a1 1 0 0 1 -1 -1v-1a2 2 0 0 0 -4 0v1a1 1 0 0 1 -1 1h-3a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1h1a2 2 0 0 0 0 -4h-1a1 1 0 0 1 -1 -1v-3a1 1 0 0 1 1 -1" />
          </svg> Created by <a href="https://cloudy1gor.github.io" class="created__link" target="_blank">Савельев Игорь</a></div>
      </div>
    </footer>
    </div>

    <?php wp_footer() ?>
    </body>

    </html>