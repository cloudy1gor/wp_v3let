<!DOCTYPE html>
<html <?php language_attributes()?>>

<head>
  <title>Главная страница</title>
  <meta name="robots" content="index, follow">
  <meta name="keywords" content="ХВВАУЛ,Харьковское ВВАУЛ,Харьковское высшее военное авиационное училище лётчиков,выпускники 1974 года,выпуск 1974 года, лучший сайт авиации">
  <meta name="description" content="Сайт выпускников ХВВАУЛ 1974 года выпуска, ХВВАУЛ-74, Взлёт.ру, v3let.ru, лучший сайт авиации">
  <meta charset="<?php bloginfo( 'charset' )?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link type="image/x-icon" rel="shortcut icon" href="images/favicon.ico">

  <?php wp_head() ?>
</head>

<body>
  <div class="wrapper">
    <header class="header">
      <div class="header-top">
        <div class="container">
          <div class="header-top__inner"><img src="images/star.png" alt="Орден" class="star" style="width: 50px; height: 50px">
            <p class="header-top__content">[ХВВАУЛ-74] Харьковское Высшее Военное Авиационное ордена Красной Звезды Училище Лётчиков ВВС им. дважды Героя Советского Союза С.И. Грицевца</p>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="header__inner">
          <div class="header__about" data-aos="fade-left" data-aos-duration="1000">
            <h1 class="header__title"><a href="/" class="header__link">Взлёт</a></h1><span class="header__subtitle">Сайт выпускников 1974 года</span>
          </div>
          <nav class="menu">
            <ul class="menu__list">
              <li class="menu__item"><svg class="menu__pic">
                  <use xlink:href="images/sprite.svg#users"></use>
                </svg> <a href="./index.html#slide" class="menu__link">Наш курс</a></li>
              <li class="menu__item"><svg class="menu__pic">
                  <use xlink:href="images/sprite.svg#history"></use>
                </svg> <a href="./history.html" class="menu__link">Исторические хроники</a></li>
              <li class="menu__item"><svg class="menu__pic">
                  <use xlink:href="images/sprite.svg#art"></use>
                </svg> <a href="./art.html" class="menu__link">Творчество</a></li>
              <li class="menu__item"><svg class="menu__pic">
                  <use xlink:href="images/sprite.svg#author"></use>
                </svg> <a href="./author.html" class="menu__link">Юрий Фёдоров</a></li>
              <li class="menu__item"><svg class="menu__pic">
                  <use xlink:href="images/sprite.svg#help"></use>
                </svg> <a href="#" class="menu__link" data-modal="data-modal">Помощь</a></li>
            </ul><button class="menu__btn"><span>Меню</span> <svg class="menu__icon">
                <use xlink:href="images/sprite.svg#menu"></use>
              </svg></button>
          </nav>
        </div>
      </div>
    </header>