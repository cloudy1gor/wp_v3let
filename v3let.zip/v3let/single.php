<?php get_header() ?>

<main class="main">
  <section class="product">
    <div class="container">

      <?php while ( have_posts() ) : the_post(); ?>

      <article class="product__wrapper" data-aos="slide-up" data-aos-duration="1000">
        <div class="product__content">
          <h2 class="product__title"><?php the_title(); ?></h2>
          <p class="product__text" data-aos="fade-in" data-aos-duration="1000">
            <!-- <img src="/images/content/2.jpg"
            alt="Изображение" class="product__img" data-aos="fade-in" data-aos-duration="1000"> -->

            <?php echo v3let_post_thumb( get_the_ID(), 'full', 'product__img' ) ?>
            <?php the_content( '' ); ?>
          </p>
        </div>

        <div class="text-muted">
          <small>
            <?php
											echo v3let_get_human_time();
											?>
          </small><br>
          <small>
            <?php
											the_tags();
											?>
          </small><br>
          <small>Категории:
            <?php
											the_category( ', ' );
											?>
          </small>
        </div>
      </article>

      <?php endwhile; ?>

    </div>
  </section>
</main>

<?php get_footer() ?>